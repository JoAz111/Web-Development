# Movie Trailer Site Project
This project is the first project in the Udacity Full Stack Web Developer Nanodegree.

A movie trailer website where I added three of my favorite movies. If you click on one of the movie's posters, the trailer of that movie will begin to play.
## Pre-requisites
* Web Browser

## Getting Started
Click on the file named fresh_tomatoes.html and you will be taken to the fresh tomatoes website I built. Click any of the movie posters to watch that movie's trailer.
